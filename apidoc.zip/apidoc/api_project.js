define({
  "name": "Join auto API documentation",
  "version": "0.1.0",
  "description": "BASE_URL https://join-auto.herokuapp.com/v1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-05-29T15:30:11.964Z",
    "url": "http://apidocjs.com",
    "version": "0.20.1"
  }
});
